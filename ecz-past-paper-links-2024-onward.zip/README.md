# Zambia ECZ past-paper source links

This link catalogue helps learners find Grade 9 and Grade 12 ECZ past-paper listings, including archive pages that display 2024 papers, and ECZ's official specimen-paper page.

## What is included

- `past-papers-links.csv`: grade, year, subjects observed, source, URL, and notes.
- Source pages only. This ZIP does **not** contain exam paper PDFs or marking schemes.

## How to use it

1. Open the CSV in a spreadsheet or text editor.
2. Open the source page for the grade you need.
3. On that page, confirm the year, exam route (such as GCE), subject, paper number, and any marking-scheme label before downloading.
4. For official specimen papers, use the ECZ page listed in the CSV.

## Coverage and rights

The third-party archive pages mix years and their listings can change. The reviewed pages showed 2024 papers for multiple Grade 9 and Grade 12 subjects, but a complete 2025–2026 set was not verified. ECZ's 2024 newsletter says past papers are not hosted on the ECZ website and are accessed through partner channels. This catalogue links to the source pages and does not copy or rehost their files. Follow the source's terms and obtain rights-holder permission before redistributing any paper.

Sources checked 4 October 2026. SifwakuLab is not affiliated with ECZ or the linked archives.
